// ============================================
// LeadBridge — shared site behaviour
// ============================================

document.addEventListener('DOMContentLoaded', () => {

  /* ---- Mobile nav toggle ---- */
  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.nav');
  if (navToggle && nav) {
    navToggle.addEventListener('click', () => {
      nav.classList.toggle('open');
      const expanded = nav.classList.contains('open');
      navToggle.setAttribute('aria-expanded', expanded);
    });
  }

  /* ---- Back to top button ---- */
  const backToTop = document.getElementById('backToTop');
  if (backToTop) {
    window.addEventListener('scroll', () => {
      backToTop.classList.toggle('show', window.scrollY > 480);
    });
    backToTop.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  /* ---- Scroll-reveal animation ---- */
  const revealEls = document.querySelectorAll('.reveal');
  if (revealEls.length) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('in');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });
    revealEls.forEach(el => io.observe(el));
  }

  /* ---- Newsletter form ---- */
  const nlForm = document.getElementById('newsletterForm');
  if (nlForm) {
    nlForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const status = document.getElementById('nlStatus');
      const emailInput = document.getElementById('nlEmail');
      status.textContent = 'Subscribing…';
      try {
        await fetch('https://formspree.io/f/mbgjrvpr', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: emailInput.value, form: 'newsletter' })
        });
        status.textContent = 'You’re subscribed. Watch your inbox.';
        nlForm.reset();
      } catch (err) {
        status.textContent = 'Something went wrong. Please try again.';
      }
    });
  }

  /* ---- Blog: category filter + search ---- */
  const postCards = document.querySelectorAll('.post-card');
  const catButtons = document.querySelectorAll('.cat-btn');
  const searchInput = document.getElementById('blogSearch');
  const noResults = document.getElementById('noResults');
  let activeCategory = 'all';

  function applyFilters() {
    if (!postCards.length) return;
    const term = (searchInput ? searchInput.value : '').trim().toLowerCase();
    let visibleCount = 0;

    postCards.forEach(card => {
      const cat = card.dataset.category || '';
      const text = card.textContent.toLowerCase();
      const matchesCategory = activeCategory === 'all' || cat === activeCategory;
      const matchesSearch = term === '' || text.includes(term);
      const visible = matchesCategory && matchesSearch;
      card.style.display = visible ? '' : 'none';
      if (visible) visibleCount++;
    });

    if (noResults) noResults.classList.toggle('show', visibleCount === 0);
  }

  catButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      catButtons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      activeCategory = btn.dataset.category;
      applyFilters();
    });
  });

  if (searchInput) {
    searchInput.addEventListener('input', applyFilters);
  }

  if (postCards.length) applyFilters();

});
